

export interface User {
    UsuarioID: number;
    Nombre: string;
    Usuario: string;
}