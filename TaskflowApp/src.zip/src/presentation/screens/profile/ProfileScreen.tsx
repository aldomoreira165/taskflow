import { Text, View } from "react-native"

export const ProfileScreen = () => {
  return (
    <View>
        <Text>ProfileScreen</Text>
    </View>
  )
}
