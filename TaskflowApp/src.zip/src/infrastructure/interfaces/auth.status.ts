
export type AuthStatus = 'authenticated' | 'unauthenticated' | 'checking';