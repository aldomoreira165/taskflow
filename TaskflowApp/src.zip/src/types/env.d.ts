declare module '@env' {
  export const API_BASE: string;
  export const STAGE: string;
  export const API_URL: string;
  export const API_URL_ANDROID: string;
  export const API_URL_IOS: string;
}